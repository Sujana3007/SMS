import java.io.IOException;  
import java.io.PrintWriter;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.*;
public class DeleteServlet extends HttpServlet {  
    protected void service(HttpServletRequest req, HttpServletResponse res)  
                    throws ServletException, IOException {
        res.setContentType("text/html");  
        PrintWriter out=res.getWriter();  
          try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = null;
	Statement selectStmt = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            selectStmt = conn.createStatement();
		PreparedStatement st = conn.prepareStatement("DELETE from stud where hno=?");
		st.setString(1,req.getParameter("rno"));
		int k = st.executeUpdate();
		if(k>0)
		out.print("Deleted Successfully");
		st.close();
            conn.close();
        }
        catch(Exception e) {
            out.print("Do not connect to DB - Error:"+e);
        }
	req.getRequestDispatcher("link.html").include(req, res);
 out.close();  
        }  
       
    }  