import javax.servlet.http.*;  
import javax.servlet.*;  
import java.io.*;  
import java.sql.*;
import java.lang.*;
public class Result extends HttpServlet
{  
public void service(ServletRequest req, ServletResponse res) 
throws ServletException,IOException  
{  
String s1,s2,s3,s4,s5,s6,s7,s8;
res.setContentType("text/html");//setting the content type  
PrintWriter pw=res.getWriter();//get the stream to write the data 
String no=req.getParameter("rno"); 
try
{
Class.forName("com.mysql.jdbc.Driver");
Connection conn = null;
Statement selectStmt = null;
conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
pw.println("Database is connected !");
PreparedStatement ps=conn.prepareStatement("select * from stud where hno=?");
ps.setString(1,no); 
pw.println("<html><body><center>");
pw.println("<table border=1>");
ResultSet rs=ps.executeQuery(); 
req.getRequestDispatcher("link1.html").include(req, res);
while(rs.next())
        {  
        s1=rs.getString(1);  
        s2=rs.getString(2);
        s3=rs.getString(3);
        s4=rs.getString(4);
        s5=rs.getString(5);
        s6=rs.getString(6);
	s7=rs.getString(7);
	s8=rs.getString(8);
	pw.println("<tr>");  
 	pw.println("<th>ROLL NUMBER</th>");   
	pw.println("<td>"+s2+"</td>");  
        pw.println("</tr>");
	pw.println("<tr>");  
 	pw.println("<th>NAME OF STUDENT</th>");   
	pw.println("<td>"+s3+"</td>");  
        pw.println("</tr>");
 	pw.println("<tr>");  
 	pw.println("<th>PRESENT SEMESTER</th>");   
	pw.println("<td>3-1</td>");  
        pw.println("</tr>");
	pw.println("<tr>");  
 	pw.println("<th>CGPA</th>");   
	pw.println("<td>"+s6+"</td>");  
        pw.println("</tr>");
        }
conn.close();
        }
        catch(Exception e) 
	{
            pw.print("Do not connect to DB - Error:"+e);
	req.getRequestDispatcher("link1.html").include(req, res);
        }
  
pw.println("</body></html>");  
  
pw.close();//closing the stream  
}}