import java.io.IOException;  
import java.io.PrintWriter;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  
import javax.servlet.http.*;  
import javax.servlet.*;  
import java.io.*;  
import java.sql.*;
import java.lang.*;
public class SLoginServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest req, HttpServletResponse res)  
                    throws ServletException, IOException {  
        res.setContentType("text/html");  
        PrintWriter out=res.getWriter(); 

	String name=req.getParameter("uname");
        String password=req.getParameter("pass");
        if(password.equals("anurag")||password.equals("admin")){  
          out.print("Welcome, "+name);
	req.getRequestDispatcher("link1.html").include(req, res);
        HttpSession session=req.getSession();  
        session.setAttribute("name",name);  
        }  
        else{  
            out.print("Sorry, username or password error!");  
            req.getRequestDispatcher("login1.html").include(req, res);  
        }  
        out.close();  
    }  
}  