import java.io.IOException;  
import java.io.PrintWriter;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.*;
public class InsertServlet extends HttpServlet {  
    protected void doPost(HttpServletRequest req, HttpServletResponse res)  
                    throws ServletException, IOException {
        res.setContentType("text/html");  
        PrintWriter out=res.getWriter();  
          try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = null;
	Statement selectStmt = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            selectStmt = conn.createStatement();
		PreparedStatement st = conn.prepareStatement("insert into stud values(?,?,?,?,?,?,?,?)");
		st.setString(1,req.getParameter("sno"));
		st.setString(2,req.getParameter("rno"));
		st.setString(3,req.getParameter("name"));
		st.setString(4,req.getParameter("mobile"));
		st.setString(5,req.getParameter("sec"));
		st.setString(6,req.getParameter("CGPA"));
		st.setString(7,req.getParameter("att"));
		st.setString(8,req.getParameter("perc"));
		int k = st.executeUpdate();
		if(k!=0)
		out.print("Inserted Successfully");
		st.close();
            conn.close();
        }
        catch(Exception e) {
            out.print("Do not connect to DB - Error:"+e);
        }
	req.getRequestDispatcher("link.html").include(req, res);
 out.close();  
        }  
       
    }  